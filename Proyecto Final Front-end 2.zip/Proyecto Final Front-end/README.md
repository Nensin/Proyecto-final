# Proyecto-final
En los recientes años a habido un auge en la cultura del colecionismo. Por un articulo en especifico, Funko Pop. Estas figuras representivas con su estilo único y caraterístico, las catapulto en ventas. Pero tambien catapulto las etafas y falta de sitios seguro para su compra. De ahi surgió "POP!" que busca ser un sitio web, seguro, transparente y  fácil de usar. 
Un sitio web que se compromete con sus usarios antes que con algo mas, que se pueda conseguir ese funko tan preciado para ti.

Para este proyecto se estuvieron utilizando las siguientes tecnologías:
HTML 5, CSS, CDFonts y JavaScript.

El proyecto no tiene forma de instalrse, ya que no esta diseñado para ese prosposito, pero se puede ejuctar con tan solo uno de los tantos archivos html gracias a lo bien que estan conectados entre ellos.
